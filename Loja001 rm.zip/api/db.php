<?php 
/*=====================================
▀▀█▀▀ █  █ █▀▀▀    █▀▀▀ █▀▀█ █ ▄▀ █▀▀▀ 
  █   █▀▀█ █▀▀▀ ▀▀ █▀▀▀ █▄▄█ █▀▄  █▀▀▀ 
  █   █  █ █▄▄▄    █    █  █ █  █ █▄▄▄
=====================================*/

// CONFIGURAÇÃO DO BANCO DE DADOS
class db {
    public static $db_server = "localhost"; 
    public static $db_db     = "sql_mercadoseguroblak_com";   
    public static $db_user   = "sql_mercadoseguroblak_com";      
    public static $db_pass   = "bd42d42dfe383";          
}

// Sobrescreve com as variáveis de ambiente (Ex: Railway, Heroku, Docker)
$host     = !empty(getenv('MYSQLHOST')) ? getenv('MYSQLHOST') : db::$db_server;
$user     = !empty(getenv('MYSQLUSER')) ? getenv('MYSQLUSER') : db::$db_user;
$password = !empty(getenv('MYSQLPASSWORD')) ? getenv('MYSQLPASSWORD') : db::$db_pass;
$database = !empty(getenv('MYSQLDATABASE')) ? getenv('MYSQLDATABASE') : db::$db_db;
if (!function_exists('get_real_ip')) {
    function get_real_ip() {
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return $_SERVER['HTTP_CF_CONNECTING_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            return trim($ips[0]);
        } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        }
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
}
$port     = !empty(getenv('MYSQLPORT')) ? getenv('MYSQLPORT') : 3306;

// Desativar exceções do MySQLi (evita erro 500 fatal no PHP 8.1+)
if (function_exists('mysqli_report')) {
    @mysqli_report(MYSQLI_REPORT_OFF);
}

// Tentar conectar com timeout reduzido
$conn = mysqli_init();
mysqli_options($conn, MYSQLI_OPT_CONNECT_TIMEOUT, 5);
@mysqli_real_connect($conn, $host, $user, $password, $database, $port);

// Verificar se a conexão falhou
if (!$conn) { 
    $error_msg = mysqli_connect_error();
    die("<div style='font-family:sans-serif; padding:50px; text-align:center;'>
            <h2 style='color:#e00;'>Erro de Conexão com o Banco de Dados</h2>
            <p>Não foi possível conectar ao banco de dados. Verifique as configurações no arquivo <strong>api/db.php</strong>.</p>
            <p style='color:#666; font-size:13px;'>Detalhe técnico: $error_msg</p>
         </div>");
}

// Definir charset para evitar problemas com acentuação
@ini_set('default_charset', 'UTF-8');
if (!headers_sent() && php_sapi_name() !== 'cli') {
    @header('Content-Type: text/html; charset=utf-8');
}
@mysqli_set_charset($conn, "utf8mb4");
@mysqli_query($conn, "SET NAMES 'utf8mb4'");
@mysqli_query($conn, "SET CHARACTER SET utf8mb4");

if (!function_exists('safe_add_column')) {
    function safe_add_column($conn, $table, $column, $definition) {
        $chk = @mysqli_query($conn, "SHOW COLUMNS FROM `$table` LIKE '$column'");
        if (!$chk || mysqli_num_rows($chk) === 0) {
            @mysqli_query($conn, "ALTER TABLE `$table` ADD COLUMN `$column` $definition");
        }
    }
}

$db_schema_flag = sys_get_temp_dir() . '/loja_db_schema_v5_' . md5(__FILE__) . '.flag';
if (!file_exists($db_schema_flag) || (time() - filemtime($db_schema_flag) > 86400)) {
    // Tabelas PIX
    @mysqli_query($conn, "CREATE TABLE IF NOT EXISTS pix_tabelas (id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(255) NOT NULL, ativa TINYINT(1) NOT NULL DEFAULT 0, criado_em DATETIME DEFAULT CURRENT_TIMESTAMP)");
    safe_add_column($conn, 'pix_tabelas', 'ativa', 'TINYINT(1) NOT NULL DEFAULT 0');
    
    $pix_status_col = @mysqli_query($conn, "SHOW COLUMNS FROM pix_tabelas LIKE 'status'");
    if ($pix_status_col && mysqli_num_rows($pix_status_col) > 0) {
        @mysqli_query($conn, "UPDATE pix_tabelas SET ativa = IF(status='ATIVA', 1, 0) WHERE ativa=0");
    }
    
    @mysqli_query($conn, "CREATE TABLE IF NOT EXISTS pix_tabela_codigos (id INT AUTO_INCREMENT PRIMARY KEY, tabela_id INT NOT NULL, valor DECIMAL(10,2) NOT NULL DEFAULT 0.00, codigo TEXT NOT NULL, status_pagamento VARCHAR(20) NOT NULL DEFAULT 'DISPONIVEL', reservado_em DATETIME DEFAULT NULL, reservado_pedido_ref VARCHAR(100) DEFAULT NULL, pago_em DATETIME DEFAULT NULL, criado_em DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_tabela_id (tabela_id), INDEX idx_status (status_pagamento)) ENGINE=InnoDB");
    safe_add_column($conn, 'pix_tabela_codigos', 'valor', 'DECIMAL(10,2) NOT NULL DEFAULT 0.00');
    safe_add_column($conn, 'pix_tabela_codigos', 'status_pagamento', "VARCHAR(20) NOT NULL DEFAULT 'DISPONIVEL'");
    safe_add_column($conn, 'pix_tabela_codigos', 'reservado_em', 'DATETIME DEFAULT NULL');
    safe_add_column($conn, 'pix_tabela_codigos', 'reservado_pedido_ref', 'VARCHAR(100) DEFAULT NULL');
    safe_add_column($conn, 'pix_tabela_codigos', 'pago_em', 'DATETIME DEFAULT NULL');
    
    // Importar registros do modelo antigo
    $old_pix_codes = @mysqli_query($conn, "SHOW TABLES LIKE 'pix_codigos_multiplos'");
    if ($old_pix_codes && mysqli_num_rows($old_pix_codes) > 0) {
        @mysqli_query($conn, "INSERT INTO pix_tabela_codigos (tabela_id, codigo, valor, status_pagamento, pago_em) SELECT tabela_id, codigo, valor, CASE WHEN status='pago' THEN 'PAGO' WHEN status='reservado' THEN 'RESERVADO' ELSE 'DISPONIVEL' END, data_uso FROM pix_codigos_multiplos old WHERE NOT EXISTS (SELECT 1 FROM pix_tabela_codigos newc WHERE newc.tabela_id=old.tabela_id AND newc.codigo=old.codigo)");
    }
    
    @mysqli_query($conn, "CREATE TABLE IF NOT EXISTS gateways_config (id INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(100) NOT NULL, status ENUM('ativo', 'inativo') DEFAULT 'inativo', taxa_pct DECIMAL(10,2) DEFAULT 0.00, taxa_fixa DECIMAL(10,2) DEFAULT 0.00, api_key VARCHAR(255) DEFAULT '', secret_key VARCHAR(255) DEFAULT '', webhook_secret VARCHAR(255) DEFAULT '')");
    
    // Garantir colunas completas para a tabela 'pix'
    @mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `pix` (`id` INT AUTO_INCREMENT PRIMARY KEY, `chave` TEXT, `tipo_chave` VARCHAR(20) DEFAULT 'aleatoria') ENGINE=InnoDB");
    safe_add_column($conn, 'pix', 'modo_pix', "VARCHAR(100) DEFAULT 'manual'");
    safe_add_column($conn, 'pix', 'pix_modo', "VARCHAR(20) NOT NULL DEFAULT 'manual'");
    safe_add_column($conn, 'pix', 'pix_max_itens', "INT(11) NOT NULL DEFAULT 4");
    safe_add_column($conn, 'pix', 'limite_por_cliente', "INT DEFAULT 4");
    safe_add_column($conn, 'pix', 'aleatorio_multiplas', "TINYINT(1) DEFAULT 0");
    safe_add_column($conn, 'pix', 'cidade', "VARCHAR(255) DEFAULT ''");
    safe_add_column($conn, 'pix', 'identificador', "VARCHAR(255) DEFAULT '***'");
    safe_add_column($conn, 'pix', 'descricao', "VARCHAR(255) DEFAULT ''");
    safe_add_column($conn, 'pix', 'beneficiario', "VARCHAR(255) DEFAULT ''");
    safe_add_column($conn, 'pix', 'use_freepay', "TINYINT(1) NOT NULL DEFAULT 0");
    safe_add_column($conn, 'pix', 'freepay_public_key', "TEXT DEFAULT NULL");
    safe_add_column($conn, 'pix', 'freepay_secret_key', "TEXT DEFAULT NULL");
    safe_add_column($conn, 'pix', 'use_mercadopago', "TINYINT(1) NOT NULL DEFAULT 0");
    safe_add_column($conn, 'pix', 'mp_access_token', "TEXT DEFAULT NULL");
    safe_add_column($conn, 'pix', 'mp_webhook_secret', "TEXT DEFAULT NULL");
    safe_add_column($conn, 'pix', 'use_pixgo', "TINYINT(1) NOT NULL DEFAULT 0");
    safe_add_column($conn, 'pix', 'pixgo_api_key', "TEXT DEFAULT NULL");
    safe_add_column($conn, 'pix', 'pixgo_webhook_secret', "TEXT DEFAULT NULL");
    safe_add_column($conn, 'pix', 'use_carthero', "TINYINT(1) NOT NULL DEFAULT 0");
    safe_add_column($conn, 'pix', 'carthero_private_key', "TEXT DEFAULT NULL");
    safe_add_column($conn, 'pix', 'carthero_public_key', "TEXT DEFAULT NULL");
    safe_add_column($conn, 'pix', 'use_bravopay', "TINYINT(1) NOT NULL DEFAULT 0");
    safe_add_column($conn, 'pix', 'bravopay_api_key', "TEXT DEFAULT NULL");
    safe_add_column($conn, 'pix', 'bravopay_webhook_secret', "TEXT DEFAULT NULL");
    safe_add_column($conn, 'pix', 'use_pix_produto', "TINYINT(1) NOT NULL DEFAULT 1");
    @mysqli_query($conn, "UPDATE pix SET pix_modo=modo_pix WHERE (pix_modo IS NULL OR pix_modo='manual') AND modo_pix IN ('copia_cola','gateway')");

    // Garantir colunas completas para a tabela 'pixgerado'
    @mysqli_query($conn, "CREATE TABLE IF NOT EXISTS pixgerado (id INT AUTO_INCREMENT PRIMARY KEY, ip VARCHAR(45), useragent TEXT, valor VARCHAR(20), produto VARCHAR(50), hora VARCHAR(20), time INT) ENGINE=InnoDB");
    safe_add_column($conn, 'pixgerado', 'produto_nome', "VARCHAR(255) DEFAULT ''");
    safe_add_column($conn, 'pixgerado', 'cliente_nome', "VARCHAR(255) DEFAULT ''");
    safe_add_column($conn, 'pixgerado', 'cliente_telefone', "VARCHAR(50) DEFAULT ''");
    safe_add_column($conn, 'pixgerado', 'cliente_cpf', "VARCHAR(20) DEFAULT ''");
    safe_add_column($conn, 'pixgerado', 'cliente_email', "VARCHAR(255) DEFAULT ''");
    safe_add_column($conn, 'pixgerado', 'status', "VARCHAR(50) DEFAULT 'pendente'");
    safe_add_column($conn, 'pixgerado', 'variacoes', "TEXT");
    safe_add_column($conn, 'pixgerado', 'pix_code', "TEXT");
    safe_add_column($conn, 'pixgerado', 'pix_qr_base64', "TEXT");
    safe_add_column($conn, 'pixgerado', 'data_criacao', "DATETIME DEFAULT CURRENT_TIMESTAMP");
    safe_add_column($conn, 'pixgerado', 'carthero_payment_id', "VARCHAR(64) DEFAULT ''");
    safe_add_column($conn, 'pixgerado', 'carthero_status', "VARCHAR(32) DEFAULT 'pending'");
    safe_add_column($conn, 'pixgerado', 'mp_transaction_id', "VARCHAR(64) DEFAULT ''");
    safe_add_column($conn, 'pixgerado', 'freepay_transaction_id', "VARCHAR(64) DEFAULT ''");
    safe_add_column($conn, 'pixgerado', 'pixgo_payment_id', "VARCHAR(64) DEFAULT ''");
    safe_add_column($conn, 'pixgerado', 'bravopay_payment_id', "VARCHAR(64) DEFAULT ''");
    safe_add_column($conn, 'pixgerado', 'bravopay_status', "VARCHAR(32) DEFAULT 'pending'");

    // Garantir colunas completas para a tabela 'online'
    @mysqli_query($conn, "CREATE TABLE IF NOT EXISTS online (id INT AUTO_INCREMENT PRIMARY KEY, ip VARCHAR(45), useragent TEXT, hora VARCHAR(20), time INT) ENGINE=InnoDB");
    safe_add_column($conn, 'online', 'etapa', "VARCHAR(50) DEFAULT ''");
    safe_add_column($conn, 'online', 'cidade', "VARCHAR(100) DEFAULT ''");
    safe_add_column($conn, 'online', 'estado', "VARCHAR(100) DEFAULT ''");
    safe_add_column($conn, 'online', 'dispositivo', "VARCHAR(50) DEFAULT 'desktop'");
    safe_add_column($conn, 'online', 'situacao', "VARCHAR(20) DEFAULT 'ativo'");
    safe_add_column($conn, 'online', 'time', "INT(11)");
    safe_add_column($conn, 'online', 'hora', "VARCHAR(20)");

    // Garantir estrutura completa para 'clientes'
    @mysqli_query($conn, "CREATE TABLE IF NOT EXISTS clientes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(255) DEFAULT NULL,
        email VARCHAR(255) DEFAULT NULL,
        cpf VARCHAR(20) DEFAULT NULL,
        celular VARCHAR(20) DEFAULT NULL,
        ip VARCHAR(100) DEFAULT NULL,
        cep VARCHAR(20) DEFAULT NULL,
        endereco VARCHAR(255) DEFAULT NULL,
        numero VARCHAR(20) DEFAULT NULL,
        bairro VARCHAR(100) DEFAULT NULL,
        cidade VARCHAR(100) DEFAULT NULL,
        estado VARCHAR(50) DEFAULT NULL,
        complemento VARCHAR(255) DEFAULT NULL,
        destinatario VARCHAR(255) DEFAULT NULL,
        quantidade VARCHAR(10) DEFAULT '1',
        valortotal VARCHAR(20) DEFAULT NULL,
        variacoes LONGTEXT DEFAULT NULL,
        produto_codigo VARCHAR(100) DEFAULT NULL,
        produto_nome VARCHAR(255) DEFAULT NULL,
        ip_real VARCHAR(100) DEFAULT NULL,
        data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    
    $colunas_clientes = [
        'estado'         => "VARCHAR(50) DEFAULT NULL",
        'destinatario'   => "VARCHAR(255) DEFAULT NULL",
        'quantidade'     => "VARCHAR(10) DEFAULT '1'",
        'valortotal'     => "VARCHAR(20) DEFAULT NULL",
        'variacoes'      => "LONGTEXT DEFAULT NULL",
        'produto_codigo' => "VARCHAR(100) DEFAULT NULL",
        'produto_nome'   => "VARCHAR(255) DEFAULT NULL",
        'ip_real'        => "VARCHAR(100) DEFAULT NULL",
        'data_cadastro'  => "TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP"
    ];
    foreach ($colunas_clientes as $nome_coluna => $definicao_coluna) {
        safe_add_column($conn, 'clientes', $nome_coluna, $definicao_coluna);
    }

    // Tabela vendas_confirmadas
    @mysqli_query($conn, "CREATE TABLE IF NOT EXISTS vendas_confirmadas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        transaction_id VARCHAR(100) NOT NULL,
        gateway VARCHAR(50) NOT NULL,
        valor DECIMAL(10,2) NOT NULL,
        cliente_nome VARCHAR(255) DEFAULT '',
        cliente_email VARCHAR(255) DEFAULT '',
        cliente_cpf VARCHAR(20) DEFAULT '',
        cliente_telefone VARCHAR(20) DEFAULT '',
        produto_nome VARCHAR(255) DEFAULT '',
        status VARCHAR(50) DEFAULT 'paid',
        data_venda DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Colunas em outras tabelas
    safe_add_column($conn, 'produto', 'cliques', "INT DEFAULT 0");
    safe_add_column($conn, 'produto', 'force_tabela_pix', "TINYINT(1) DEFAULT 0");
    safe_add_column($conn, 'config', 'app_mobile_ativo', "TINYINT(1) DEFAULT 0");
    safe_add_column($conn, 'config', 'cartao_ativo', "TINYINT(1) DEFAULT 1");
    safe_add_column($conn, 'apis', 'smtp_ativo', "TINYINT(1) DEFAULT 1");

    @file_put_contents($db_schema_flag, time());
}
?>
